import { Body, Controller, Get, Param, ParseIntPipe, Post, Put } from '@nestjs/common';
import { WorkWeekTemplateService } from './week-template.service';
import { CreateWorkWeekTemplateDto, UpdateWorkWeekTemplateDto } from './dto/week-template.dto';






@Controller('work/templates')
export class WorkWeekTemplateController {
    constructor(private readonly svc: WorkWeekTemplateService) {}

    @Get()
    list() {
        return this.svc.list();
    }

    @Get(':id')
    getOne(@Param('id', ParseIntPipe) id: number) {
        return this.svc.getOne(id);
    }

    @Post()
    create(@Body() dto: CreateWorkWeekTemplateDto) {
        return this.svc.create(dto);
    }

    @Put(':id')
    update(@Param('id', ParseIntPipe) id: number, @Body() dto: UpdateWorkWeekTemplateDto) {
        return this.svc.update(id, dto);
    }
}