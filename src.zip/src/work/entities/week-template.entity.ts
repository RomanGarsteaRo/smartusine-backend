import { Column, CreateDateColumn, Entity, Index, PrimaryGeneratedColumn, UpdateDateColumn } from 'typeorm';





export type WorkWeekTemplate = Record<DowKey, WorkWindow[]>;
export type DowKey = '0'|'1'|'2'|'3'|'4'|'5'|'6';
export interface WorkWindow {
    sMin: number; // minute from midnight [0..1440)
    eMin: number; // minute from midnight (0..1440]
}





@Entity('work_week_template')
@Index(['name'], { unique: true })
export class WorkWeekTemplateEntity {

    @PrimaryGeneratedColumn({ unsigned: true })
    id!: number;

    @Column({ type: 'varchar', length: 120 })
    name!: string;

    @Column({ type: 'varchar', length: 64, default: 'America/Montreal' })
    timezone!: string;

    /**
     * Stored as LONGTEXT in MariaDB via TypeORM.
     */
    @Column({ type: 'simple-json', name: 'week' })
    week!: WorkWeekTemplate;

    @Column({ type: 'int', unsigned: true, default: 1 })
    version!: number;

    @CreateDateColumn({ type: 'datetime', name: 'created_at', precision: 6 })
    createdAt!: Date;

    @UpdateDateColumn({ type: 'datetime', name: 'updated_at', precision: 6 })
    updatedAt!: Date;
}