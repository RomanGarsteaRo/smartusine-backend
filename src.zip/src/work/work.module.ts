import { WorkWeekTemplateService } from './week-template.service';
import { WorkWeekTemplateController } from './week-template.controller';
import { WorkWeekTemplateEntity } from './entities/week-template.entity';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Module } from '@nestjs/common';




@Module({
    imports: [
        TypeOrmModule.forFeature([WorkWeekTemplateEntity]),
    ],
    controllers: [WorkWeekTemplateController],
    providers: [WorkWeekTemplateService],
    exports: [WorkWeekTemplateService],
})
export class WorkModule {}