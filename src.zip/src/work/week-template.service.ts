import { DowKey, WorkWeekTemplate, WorkWeekTemplateEntity } from './entities/week-template.entity';
import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { CreateWorkWeekTemplateDto, UpdateWorkWeekTemplateDto } from './dto/week-template.dto';


const DOWS: DowKey[] = ['0','1','2','3','4','5','6'];

function normalizeAndValidateWeek(week: WorkWeekTemplate): WorkWeekTemplate {
    // ensure all keys exist
    for (const k of DOWS) {
        if (!Array.isArray((week as any)[k])) (week as any)[k] = [];
    }

    // validate each day windows
    for (const k of DOWS) {
        const arr = week[k];

        for (const w of arr) {
            if (!Number.isFinite(w.sMin) || !Number.isFinite(w.eMin)) {
                throw new BadRequestException(`week[${k}] window has non-finite sMin/eMin`);
            }
            if (w.sMin < 0 || w.sMin > 1440 || w.eMin < 0 || w.eMin > 1440) {
                throw new BadRequestException(`week[${k}] window out of range 0..1440`);
            }
            if (w.eMin <= w.sMin) {
                throw new BadRequestException(`week[${k}] window must satisfy eMin > sMin`);
            }
        }

        // sort and check overlaps
        arr.sort((a, b) => a.sMin - b.sMin || a.eMin - b.eMin);

        for (let i = 1; i < arr.length; i++) {
            const prev = arr[i - 1];
            const cur = arr[i];
            if (cur.sMin < prev.eMin) {
                throw new BadRequestException(`week[${k}] windows overlap`);
            }
        }
    }

    return week;
}



@Injectable()
export class WorkWeekTemplateService {


    constructor(
        @InjectRepository(WorkWeekTemplateEntity)
        private readonly repo: Repository<WorkWeekTemplateEntity>,
    ) {}



    async list(): Promise<WorkWeekTemplateEntity[]> {
        return this.repo.find({ order: { updatedAt: 'DESC' } });
    }

    async getOne(id: number): Promise<WorkWeekTemplateEntity> {
        const row = await this.repo.findOne({ where: { id } });
        if (!row) throw new NotFoundException(`work_week_template ${id} not found`);
        return row;
    }

    async create(dto: CreateWorkWeekTemplateDto): Promise<WorkWeekTemplateEntity> {
        const week = normalizeAndValidateWeek(dto.week);

        const row = this.repo.create({
            name: dto.name.trim(),
            timezone: (dto.timezone?.trim() || 'America/Montreal'),
            week,
            version: 1,
        });

        return this.repo.save(row);
    }

    async update(id: number, dto: UpdateWorkWeekTemplateDto): Promise<WorkWeekTemplateEntity> {
        const row = await this.getOne(id);

        if (dto.name !== undefined) row.name = dto.name.trim();
        if (dto.timezone !== undefined) row.timezone = dto.timezone.trim();
        if (dto.week !== undefined) row.week = normalizeAndValidateWeek(dto.week);
        row.version = (row.version ?? 1) + 1;
        return this.repo.save(row);
    }
}