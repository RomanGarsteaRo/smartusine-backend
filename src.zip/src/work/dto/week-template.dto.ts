import { IsInt, IsNotEmpty, IsObject, IsOptional, IsString, Max, Min } from 'class-validator';
import type { WorkWeekTemplate } from '../entities/week-template.entity';

export class WorkWindowDto {
    @IsInt()
    @Min(0)
    @Max(1440)
    sMin!: number;

    @IsInt()
    @Min(0)
    @Max(1440)
    eMin!: number;
}

export class CreateWorkWeekTemplateDto {

    @IsString()
    @IsNotEmpty()
    name!: string;

    @IsOptional()
    @IsString()
    timezone?: string;

    /**
     * Keys: "0".."6"
     * Values: WorkWindowDto[]
     */
    @IsObject()
    week!: WorkWeekTemplate;
}

export class UpdateWorkWeekTemplateDto {

    @IsOptional()
    @IsString()
    @IsNotEmpty()
    name?: string;

    @IsOptional()
    @IsString()
    timezone?: string;

    @IsOptional()
    @IsObject()
    week?: WorkWeekTemplate;
}

export class WorkWeekTemplateResponseDto {
    id!: number;
    name!: string;
    timezone!: string;
    week!: WorkWeekTemplate;
    version!: number;
    createdAt!: string;
    updatedAt!: string;
}